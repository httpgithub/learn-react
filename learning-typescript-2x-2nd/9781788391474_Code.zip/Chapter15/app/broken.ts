import { Ninja } from "./ninja";
import { Katana } from "./katana";

const ninja = new Ninja(new Katana());

ninja.fight("5");
