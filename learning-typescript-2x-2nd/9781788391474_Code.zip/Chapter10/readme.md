# Chapter 10

```
cd cd chapters/chapter_10
npm install
ts-node 01_callback.ts
ts-node 02_promisify.ts
ts-node 03_file_system.ts
ts-node 04_database.ts
ts-node 05_http_hello.ts
ts-node 06_express_hello.ts
ts-node 07_express_routing.ts
ts-node 08_express_middleware.ts
```

```
ts-node 09_mvc/index.ts
```

```
ts-node 10_inversify_express_utils/index.ts
```
