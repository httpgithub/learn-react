export const TYPE = {
    MovieRepository: Symbol("MovieRepository")
};
