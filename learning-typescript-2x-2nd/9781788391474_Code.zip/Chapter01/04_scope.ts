namespace scope_demo {

    var myNumber: number = 1;
    let isValid: boolean = true;
    const apiKey: string = "0E5CE8BD-6341-4CC2-904D-C4A94ACD276E";

}
