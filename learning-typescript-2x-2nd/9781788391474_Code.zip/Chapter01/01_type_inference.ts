namespace type_inference_demo {

    let counter1;              // unknown (any) type
    let counter2 = 0;          // number (inferred)
    let counter3: number;      // number
    let counter4: number = 0;  // number

}
