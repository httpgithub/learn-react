namespace App {
    export namespace Models {
        export class UserModel {
            // ...
        }
        export class TalkModel {
            // ...
        }
    }
}

const user = new App.Models.UserModel();
const talk = new App.Models.TalkModel();
