namespace Models {
    export class UserModel {
        // ...
    }
}
