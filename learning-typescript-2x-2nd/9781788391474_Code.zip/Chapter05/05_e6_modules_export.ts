class UserModel {
    // ...
}

export class TalkModel {
    // ...
}

export { UserModel };
