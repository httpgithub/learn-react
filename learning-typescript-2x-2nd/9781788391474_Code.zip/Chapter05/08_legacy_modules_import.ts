import User = require("./07_legacy_modules_export");
