class User {
    // …
}
export = User;
