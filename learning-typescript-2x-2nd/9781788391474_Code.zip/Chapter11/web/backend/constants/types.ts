export const TYPE = {
    ActorRepository: Symbol("ActorRepository"),
    MovieRepository: Symbol("MovieRepository")
};
