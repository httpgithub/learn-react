export interface ActorInterface {
    id: number;
    name: string;
    yearBorn: number;
}
