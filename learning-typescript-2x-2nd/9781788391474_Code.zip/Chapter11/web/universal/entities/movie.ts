export interface MovieInterface {
    id: number;
    title: string;
    year: number;
}
