export const TYPE = {
    ActorStore: Symbol("ActorStore"),
    MovieStore: Symbol("MovieStore")
};
